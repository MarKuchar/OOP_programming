package midtermexam;

/**
 *
 * @author martin.kuchar
 * */
public interface Steerable {
    void accelerate();
    void steerLeft();
    void steerRight();
}
